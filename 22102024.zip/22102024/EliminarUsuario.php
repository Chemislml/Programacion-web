<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1 style=" text-align: center;" >Elimina Usuario</h1>
    <form style=" text-align: center;" method="POST" action="deleteUsuario.php">

        <input  type="text" name="no_cuenta" placeholder="Numero de Cuenta" />
        <br />
        <button type="submit">Eliminar usuario</button>

    </form>
    
    <h1><a href="index.php">Inicio de listas</a></h1>

</body>

</html>