<?php
$nombreUser= $_POST['nombre_usuario'];

echo $nombreUser;
?>
<style>
    h1{
        color:red;
    }
</style>

<h1> Hola tu nombre es:  <?php echo $nombreUser;?></h1>